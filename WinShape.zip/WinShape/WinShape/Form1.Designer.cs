﻿namespace WinShape
{
    partial class WinShape
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpShape = new System.Windows.Forms.GroupBox();
            this.rbtnSquare = new System.Windows.Forms.RadioButton();
            this.rbtnRectangle = new System.Windows.Forms.RadioButton();
            this.grpRectangle = new System.Windows.Forms.GroupBox();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtRecLength = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpSquare = new System.Windows.Forms.GroupBox();
            this.txtSqLength = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtNoOfSides = new System.Windows.Forms.TextBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.grpShape.SuspendLayout();
            this.grpRectangle.SuspendLayout();
            this.grpSquare.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpShape
            // 
            this.grpShape.Controls.Add(this.rbtnSquare);
            this.grpShape.Controls.Add(this.rbtnRectangle);
            this.grpShape.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpShape.Location = new System.Drawing.Point(27, 21);
            this.grpShape.Name = "grpShape";
            this.grpShape.Size = new System.Drawing.Size(200, 100);
            this.grpShape.TabIndex = 0;
            this.grpShape.TabStop = false;
            this.grpShape.Text = "Shape";
            // 
            // rbtnSquare
            // 
            this.rbtnSquare.AutoSize = true;
            this.rbtnSquare.Location = new System.Drawing.Point(19, 51);
            this.rbtnSquare.Name = "rbtnSquare";
            this.rbtnSquare.Size = new System.Drawing.Size(86, 25);
            this.rbtnSquare.TabIndex = 1;
            this.rbtnSquare.TabStop = true;
            this.rbtnSquare.Text = "Square";
            this.rbtnSquare.UseVisualStyleBackColor = true;
            this.rbtnSquare.CheckedChanged += new System.EventHandler(this.rbtnSquare_CheckedChanged);
            // 
            // rbtnRectangle
            // 
            this.rbtnRectangle.AutoSize = true;
            this.rbtnRectangle.Location = new System.Drawing.Point(19, 28);
            this.rbtnRectangle.Name = "rbtnRectangle";
            this.rbtnRectangle.Size = new System.Drawing.Size(110, 25);
            this.rbtnRectangle.TabIndex = 0;
            this.rbtnRectangle.TabStop = true;
            this.rbtnRectangle.Text = "Rectangle";
            this.rbtnRectangle.UseVisualStyleBackColor = true;
            this.rbtnRectangle.CheckedChanged += new System.EventHandler(this.rbtnRectangle_CheckedChanged);
            // 
            // grpRectangle
            // 
            this.grpRectangle.Controls.Add(this.txtWidth);
            this.grpRectangle.Controls.Add(this.txtRecLength);
            this.grpRectangle.Controls.Add(this.label3);
            this.grpRectangle.Controls.Add(this.label2);
            this.grpRectangle.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRectangle.Location = new System.Drawing.Point(27, 140);
            this.grpRectangle.Name = "grpRectangle";
            this.grpRectangle.Size = new System.Drawing.Size(281, 145);
            this.grpRectangle.TabIndex = 1;
            this.grpRectangle.TabStop = false;
            this.grpRectangle.Text = "Rectangle";
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(80, 81);
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(172, 29);
            this.txtWidth.TabIndex = 13;
            // 
            // txtRecLength
            // 
            this.txtRecLength.Location = new System.Drawing.Point(80, 35);
            this.txtRecLength.Name = "txtRecLength";
            this.txtRecLength.Size = new System.Drawing.Size(172, 29);
            this.txtRecLength.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 21);
            this.label3.TabIndex = 5;
            this.label3.Text = "Width";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Length";
            // 
            // grpSquare
            // 
            this.grpSquare.Controls.Add(this.txtSqLength);
            this.grpSquare.Controls.Add(this.label6);
            this.grpSquare.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSquare.Location = new System.Drawing.Point(387, 140);
            this.grpSquare.Name = "grpSquare";
            this.grpSquare.Size = new System.Drawing.Size(283, 84);
            this.grpSquare.TabIndex = 2;
            this.grpSquare.TabStop = false;
            this.grpSquare.Text = "Square";
            // 
            // txtSqLength
            // 
            this.txtSqLength.Location = new System.Drawing.Point(114, 32);
            this.txtSqLength.Name = "txtSqLength";
            this.txtSqLength.Size = new System.Drawing.Size(154, 29);
            this.txtSqLength.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 21);
            this.label6.TabIndex = 8;
            this.label6.Text = "Length";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(418, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Shape";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(418, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 21);
            this.label4.TabIndex = 6;
            this.label4.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(418, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 21);
            this.label5.TabIndex = 7;
            this.label5.Text = "No. of Sides";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(547, 53);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(187, 29);
            this.txtName.TabIndex = 9;
            // 
            // txtNoOfSides
            // 
            this.txtNoOfSides.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfSides.Location = new System.Drawing.Point(544, 89);
            this.txtNoOfSides.Name = "txtNoOfSides";
            this.txtNoOfSides.Size = new System.Drawing.Size(187, 29);
            this.txtNoOfSides.TabIndex = 10;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Font = new System.Drawing.Font("Microsoft Yi Baiti", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplay.Location = new System.Drawing.Point(595, 296);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(136, 49);
            this.btnDisplay.TabIndex = 11;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // WinShape
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.txtNoOfSides);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grpSquare);
            this.Controls.Add(this.grpRectangle);
            this.Controls.Add(this.grpShape);
            this.Name = "WinShape";
            this.Text = "Shape";
            this.Load += new System.EventHandler(this.Shape_Load);
            this.grpShape.ResumeLayout(false);
            this.grpShape.PerformLayout();
            this.grpRectangle.ResumeLayout(false);
            this.grpRectangle.PerformLayout();
            this.grpSquare.ResumeLayout(false);
            this.grpSquare.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpShape;
        private System.Windows.Forms.RadioButton rbtnSquare;
        private System.Windows.Forms.RadioButton rbtnRectangle;
        private System.Windows.Forms.GroupBox grpRectangle;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtRecLength;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpSquare;
        private System.Windows.Forms.TextBox txtSqLength;
        private System.Windows.Forms.Label label6;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtNoOfSides;
        private System.Windows.Forms.Button btnDisplay;
    }
}

