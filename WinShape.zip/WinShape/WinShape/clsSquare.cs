﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConShape
{
    internal class clsSquare : clsShape
    {
        private double side1;

        public clsSquare()
        {

        }

        public clsSquare(string name, int side, double side1)
        {
            base.Name = name;
            base.Sides = side;
            this.side1 = side1;
        }

        public clsSquare(TextBox txtName, int v1, double v2, double v3)
        {
            TxtName = txtName;
            V1 = v1;
            V2 = v2;
            V3 = v3;
        }

        public override string ToString()
        {
            return "Name: " + base.Name +
                "\n Sides: " + base.Sides +
                "\n Area: " + this.ComputeArea() +
                "\n Perimeter: " + this.ComputePerimeter() +
                "\n Length of one side: " + this.side1;
        }

        public override double ComputeArea()
        {
            return Math.Pow(this.side1, 2);
        }

        public override double ComputePerimeter()
        {
            return this.side1 * 4;
        }

        public double Side1 { get => side1; set => side1 = value; }
        public TextBox TxtName { get; }
        public int V1 { get; }
        public double V2 { get; }
        public double V3 { get; }
    }
}
