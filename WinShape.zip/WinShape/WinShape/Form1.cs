﻿using ConShape;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinShape
{
    public partial class WinShape : Form
    {
        public WinShape()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            
            //
            
            if (rbtnRectangle.Checked)
            {
                clsRectangle rec = new clsRectangle(txtName.Text, int.Parse(txtNoOfSides.Text), double.Parse(txtRecLength.Text), double.Parse(txtWidth.Text));          
                MessageBox.Show(rec.ToString());
            }
            else
            {
                clsSquare sq = new clsSquare(txtName.Text, int.Parse(txtNoOfSides.Text), double.Parse(txtSqLength.Text));
                MessageBox.Show(sq.ToString());
            }

        }

        private void Shape_Load(object sender, EventArgs e)
        {
            grpSquare.Visible = false;
            grpRectangle.Visible = false;
        }

        private void rbtnRectangle_CheckedChanged(object sender, EventArgs e)
        {
            if(rbtnRectangle.Checked)
            {
                grpRectangle.Visible = true;
            }
            else
            {
                grpRectangle.Visible = false;
            }
        }

        private void rbtnSquare_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnSquare.Checked)
            {
                grpSquare.Visible = true;
            }
            else
            {
                grpSquare.Visible = false;
            }
        }
    }
}
